//
//  JADBannerView.h
//  JADYun
//
//  Created by wangshuai331 on 2020/8/18.
//  Copyright © 2020 JD.COM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JADBannerViewDelegate.h"

NS_ASSUME_NONNULL_BEGIN

/// A customized UIView to represent a JADYun ad (banner ad).
@interface JADBannerView : UIView

/**
 * The bannerView's ad placement ID.
 * 属性：代码位ID
 */
@property (nonatomic, strong, readonly, nullable) NSString *placementID;

/**
 * hide close button
 * 隐藏关闭按钮属性
 */
@property (nonatomic, assign) BOOL hideCloseButton;

/**
 * The bannerView's ad delegate.
 * banner视图 delegate
 */
@property (nonatomic, weak) id<JADBannerViewDelegate> delegate;

/**
 * Ad price
 * 广告价格（单位：分）
 */
@property (nonatomic, assign, readonly) NSInteger price;

/**
 * 初始化横幅广告view
 * @param placementID 代码位ID
 * @param adSize 代码位大小，注意：与管理平台的配置保持一致
 * @param rootViewController 代码位所在的UIViewController
 * @param isSupportDeepLink 是否支持 deep link 默认为 YES
 */
- (instancetype)initWithPlacementID:(NSString *)placementID
                             adSize:(CGSize)adSize
                 rootViewController:(UIViewController *)rootViewController
                  isSupportDeepLink:(BOOL)isSupportDeepLink;

/**
 * Load banner view ad data.
 * 加载banner广告
 */
- (void)loadAdData;

@end

NS_ASSUME_NONNULL_END
