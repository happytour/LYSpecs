//
//  KSAdSplashDelegate.h
//  Pods
//
//  Created by zhangchuntao on 2021/3/3.
//

#ifndef KSAdSplashDelegate_h
#define KSAdSplashDelegate_h

#endif /* KSAdSplashDelegate_h */
